void DessinerGrille(int carre);
void NettoyerEcran();
void AfficherTemps(int seconde, int minute, int carre);
void AfficherScore(int score);
void AfficherGameOver();
