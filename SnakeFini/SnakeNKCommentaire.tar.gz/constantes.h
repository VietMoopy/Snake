#define delta 1000000L
#define NB_PIXEL_X_FENETRE 840
#define NB_PIXEL_Y_FENETRE 602
#define NB_PIXEL_X_JEU 840
#define NB_PIXEL_Y_JEU 560
#define NB_POMME 5
#define NB_OBSTACLE 15
#define TAILLE_INITIAL_SERPENT 10
#define VITESSE_SERPENT 65000
#define CENTRE_X_GRILLE 30
#define CENTRE_Y_GRILLE 20
#define CENTRE_X  540
#define CENTRE_Y 360
#define UP 1
#define DOWN 2
#define LEFT 3
#define RIGHT 4
#define MINGRILLE 1
#define MAXGRILLEX 59 // De 0 à 59 => 60 en horizontale
#define MAXGRILLEY 39  // De 0 à 39 => 40 en verticale
